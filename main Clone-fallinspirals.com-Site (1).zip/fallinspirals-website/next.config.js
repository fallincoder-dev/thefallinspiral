/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  distDir: 'out',
  images: {
    unoptimized: true,
  },
  basePath: '',
  // Change this to your repo name if you're deploying to GitHub Pages subdirectory
  // basePath: '/repo-name',
};

module.exports = nextConfig;
