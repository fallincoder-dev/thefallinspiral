# fallinspirals.com Website

A portfolio website for Amber Arantza, styled after the Quinn template.

## Local Development

```bash
# Install dependencies
npm install
# or
bun install

# Start the development server
npm run dev
# or
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Deploying to GitHub Pages

This project is configured for easy deployment to GitHub Pages:

1. **Create a GitHub repository**:
   - Create a new repository on GitHub
   - Push this code to your repository

2. **Enable GitHub Pages**:
   - Go to your repository's Settings
   - Navigate to "Pages" in the sidebar
   - Under "Build and deployment", select "GitHub Actions" as the source
   - The included workflow file will handle the build and deployment

3. **Custom Domain (Optional)**:
   - In your repository's Settings > Pages
   - Enter your custom domain in the "Custom domain" field
   - Update the `basePath` in `next.config.js` if needed

## Project Structure

- `/src/app`: Contains all page components and global styles
- `/public`: Static assets
- `/components`: Reusable UI components

## Customization

To make further changes to the website:

1. Edit content in the page files under `/src/app`
2. Modify styles in `/src/app/globals.css`
3. Update images by replacing the image URLs in the components

## Notes

This is a [Next.js](https://nextjs.org/) project with static export, using:
- [Tailwind CSS](https://tailwindcss.com/) for styling
- [shadcn/ui](https://ui.shadcn.com/) for UI components
