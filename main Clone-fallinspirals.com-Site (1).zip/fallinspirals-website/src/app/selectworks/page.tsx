import Image from "next/image";
import Link from "next/link";

export default function SelectWorksPage() {
  return (
    <div className="px-6 md:px-16 lg:px-24 py-8">
      <h1 className="section-title text-2xl md:text-3xl mb-12">Select Works</h1>

      <div className="space-y-24 md:space-y-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-center">
          <div className="space-y-4">
            <h2 className="work-title">203 Issue</h2>
            <Link href="/203issue" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="relative h-[400px] md:h-[500px]">
            <Image
              src="https://ext.same-assets.com/4233618056/3157989300.jpeg"
              alt="Fashion work 1"
              fill
              style={{objectFit: "cover"}}
              priority
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-center">
          <div className="space-y-4">
            <h2 className="work-title">SQSP Magazine</h2>
            <Link href="/sqspmagazine" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="relative h-[400px] md:h-[500px]">
            <Image
              src="https://ext.same-assets.com/4233618056/1140172244.jpeg"
              alt="Fashion work 2"
              fill
              style={{objectFit: "cover"}}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-center">
          <div className="space-y-4">
            <h2 className="work-title">Editorial Styling</h2>
            <Link href="/editorialstyling" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="relative h-[400px] md:h-[500px]">
            <Image
              src="https://ext.same-assets.com/4233618056/3933946805.jpeg"
              alt="Fashion work 3"
              fill
              style={{objectFit: "cover"}}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-center">
          <div className="space-y-4">
            <h2 className="work-title">Street Photography</h2>
            <Link href="/streetstyle" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="relative h-[400px] md:h-[500px]">
            <Image
              src="https://ext.same-assets.com/4233618056/787278551.jpeg"
              alt="Fashion work 4"
              fill
              style={{objectFit: "cover"}}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
