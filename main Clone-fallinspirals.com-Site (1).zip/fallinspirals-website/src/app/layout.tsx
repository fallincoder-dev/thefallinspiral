import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Link from "next/link";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "fallinspirals.com",
  description: "Amber Arantza - Stylist & Creative Director",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex flex-col min-h-screen">
          <header className="py-6 px-6 md:px-16 lg:px-24">
            <div className="flex justify-between items-center">
              <div>
                <Link href="/" className="main-title md:text-xl lg:text-2xl xl:text-[30px] text-[22px] m-[0px] px-[0px] py-[16px]">
                  fallinspirals.com
                </Link>
              </div>
              <nav className="flex gap-4 md:gap-6">
                <Link href="/info" className="nav-link xl:text-[22px] text-left px-[8px]">
                  Info
                </Link>
                <Link href="/selectworks" className="nav-link xl:text-[22px]">
                  Select Works
                </Link>
              </nav>
            </div>
          </header>
          <main className="flex-grow">
            {children}
          </main>
          <footer className="py-8 px-6 md:px-16 lg:px-24">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex flex-col">
                <div className="main-title text-lg md:text-xl xl:text-[39px] text-left px-[23px]">
                  fallinspirals.com
                </div>
                <div className="footer-text xl:text-[27px] text-center">amber@fallinspirals.comm
                </div>
              </div>
              <div className="flex gap-4 rounded-[0px] mx-[0px] px-[110px] py-[2px]">
                <Link href="https://www.instagram.com/" className="social-links xl:text-[22px]">
                  Instagram
                </Link>
                <Link href="mailto:hello@fallinspirals.com" className="social-links xl:text-[22px]">
                  Email
                </Link>
                <Link href="https://www.linkedin.com/" className="social-links xl:text-[22px]">inPrintn
                </Link>
              </div>
            </div>
            <div className="mt-4 text-xs text-[#CF4730] text-center">Made with Love (2025)e
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
