import { Separator } from "@/components/ui/separator";
import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div className="px-6 md:px-16 lg:px-24 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
        <div className="space-y-6 md:space-y-12">
          <h1 className="portfolio-text md:text-5xl xl:text-[85px] text-[#CF4730] text-[74px] text-left m-[0px] px-[0px] py-[29px]">Amber Arantza</h1>

          <div className="portfolio-text text-4xl md:text-5xl mt-6"></div>

          <div className="mt-16 md:mt-32 space-y-6">
            <p className="text-lg md:text-xl xl:font-medium xl:text-[24px]">I'm Amber, you could say my love for art has always been there; in fact, perhaps since my grandfather and my father, but I began to develop it in 2020, when I asked my dad for some watercolors, and he bought them for me, which made me feel incredibly excited. I couldn't stop painting; it's like something I need to do to survive in this world...
            </p>
            <p className="text-lg md:text-xl">.
            </p>
          </div>
        </div>

        <div className="relative h-[400px] md:h-[600px]">
          <Image
            src="https://ugc.same-assets.com/4VhYaoExHcyJNZnTic_Dh033CQf_HuDu.jpeg"
            alt="Photographer with camera"
            fill
            style={{objectFit: "cover"}}
            priority
          />
        </div>
      </div>

      <div className="mt-16 md:mt-32">
        <h2 className="main-title text-2xl md:text-3xl text-center">
          fallinspirals.com
        </h2>
        <h3 className="section-title text-center mt-2">Artistr
        </h3>
      </div>

      <div className="mt-16 md:mt-32">
        <h2 className="section-title mb-6 xl:text-[45px]">Select Works</h2>
        <Separator className="bg-muted" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          <div className="space-y-4">
            <div className="h-[300px] md:h-[400px] relative">
              <Image
                src="https://ugc.same-assets.com/9B_qptKQvg_2eCQ02jVhQ54Gq4dnd7m3.jpeg"
                alt="Fashion work 1"
                fill
                style={{objectFit: "cover"}}
              />
            </div>
            <h3 className="work-title">Sketchbooks</h3>
            <Link href="/203issue" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="space-y-4">
            <div className="h-[300px] md:h-[400px] relative">
              <Image
                src="https://ugc.same-assets.com/uSwSrr5PHO73429vjdvE4keePNy7UtCH.jpeg"
                alt="Fashion work 2"
                fill
                style={{objectFit: "cover"}}
              />
            </div>
            <h3 className="work-title">portraits</h3>
            <Link href="/sqspmagazine" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="space-y-4">
            <div className="h-[300px] md:h-[400px] relative">
              <Image
                src="https://ugc.same-assets.com/by4UeG_DtvGtLXC6G35kULZTg9Kz1mZl.jpeg"
                alt="Fashion work 3"
                fill
                style={{objectFit: "cover"}}
              />
            </div>
            <h3 className="work-title">art & commissions</h3>
            <Link href="/editorialstyling" className="text-primary hover:underline">
              View project
            </Link>
          </div>

          <div className="space-y-4">
            <div className="h-[300px] md:h-[400px] relative">
              <Image
                src="https://ugc.same-assets.com/qvB3KhiZLrB-oM4tbyAj9-a5meYfKK7m.jpeg"
                alt="Fashion work 4"
                fill
                style={{objectFit: "cover"}}
              />
            </div>
            <h3 className="work-title">Photography</h3>
            <Link href="/streetstyle" className="text-primary hover:underline">
              View project
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mt-16 md:mt-32">
        <div className="relative h-[400px] md:h-[500px]">
          <Image
            src="https://ugc.same-assets.com/oU86zE_zNkJX7_R2t2Si1cVW5JzwAmN6.jpeg"
            alt="Profile photo"
            fill
            style={{objectFit: "cover"}}
          />
        </div>

        <div className="space-y-6">
          <p className="text-lg md:text-xl">When.
          </p>
          <p className="text-lg">.
          </p>

          <div className="mt-12">
            <h3 className="section-title mb-2">Latest Project</h3>
            <p className="text-lg">
              Transit street photography,<br />
              Launching early next year
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-16 mt-16 md:mt-32">
        <div>
          <h3 className="section-title mb-6">Client List</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <span>Creative Direction,<br />2021</span>
              <span className="client-list"></span>
            </div>

            <div className="flex justify-between items-start">
              <span></span>
              <span className="client-list"></span>
            </div>

            <div className="flex justify-between items-start">
              <span></span>
              <span className="client-list"></span>
            </div>

            <div className="flex justify-between items-start">
              <span>Associate Stylist,<br />2019</span>
              <span className="client-list"></span>
            </div>

            <div className="flex justify-between items-start">
              <span>Associate Stylist,<br />2020</span>
              <span className="client-list"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
