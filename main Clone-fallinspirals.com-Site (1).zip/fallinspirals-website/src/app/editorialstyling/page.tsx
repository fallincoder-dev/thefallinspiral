import Image from "next/image";
import Link from "next/link";

export default function ProjectPage() {
  return (
    <div className="px-6 md:px-16 lg:px-24 py-8">
      <h1 className="work-title mb-8">Editorial Styling</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
        <div className="space-y-6">
          <p className="text-lg md:text-xl">
            A collection of editorial styling projects for various fashion publications and brands.
          </p>
          <p className="text-lg">
            These projects demonstrate versatility in styling approaches, from classic to avant-garde.
          </p>
        </div>

        <div className="relative h-[400px] md:h-[600px]">
          <Image
            src="https://ext.same-assets.com/4233618056/3933946805.jpeg"
            alt="Editorial Styling"
            fill
            style={{objectFit: "cover"}}
            priority
          />
        </div>
      </div>

      <div className="mt-16">
        <Link href="/selectworks" className="text-primary hover:underline">
          ← Back to Select Works
        </Link>
      </div>
    </div>
  );
}
