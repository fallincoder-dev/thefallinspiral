import Image from "next/image";
import Link from "next/link";

export default function InfoPage() {
  return (
    <div className="px-6 md:px-16 lg:px-24 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
        <div className="space-y-6 md:space-y-12">
          <h1 className="section-title text-2xl md:text-3xl">Stylist & Creative Director</h1>

          <div className="mt-8 space-y-6">
            <p className="text-lg md:text-xl">
              Born and raised in Brooklyn. Lived and learned in London. I'm a stylist and creative director leaving my fingerprints on the fashion world at every turn. From directing editorial shoots in London to snapping film behind the scenes, I'm inspired by clothes and the people who wear them.
            </p>
            <p className="text-lg md:text-xl">
              I'm currently available for consulting engagements.
            </p>
          </div>
        </div>

        <div className="relative h-[400px] md:h-[600px]">
          <Image
            src="https://ext.same-assets.com/4233618056/2086426859.jpeg"
            alt="Profile photo"
            fill
            style={{objectFit: "cover"}}
            priority
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-16 mt-16 md:mt-32">
        <div>
          <h3 className="section-title mb-6">Client List</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <span>Creative Direction,<br />2021</span>
              <span className="client-list">#Magazine</span>
            </div>

            <div className="flex justify-between items-start">
              <span>Stylist, 2022</span>
              <span className="client-list">SQSP launch</span>
            </div>

            <div className="flex justify-between items-start">
              <span>Stylist, 2020</span>
              <span className="client-list">Editorial Collection</span>
            </div>

            <div className="flex justify-between items-start">
              <span>Associate Stylist,<br />2019</span>
              <span className="client-list">Arantza Issue No.2</span>
            </div>

            <div className="flex justify-between items-start">
              <span>Associate Stylist,<br />2020</span>
              <span className="client-list">Arantza Issue No.1</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
